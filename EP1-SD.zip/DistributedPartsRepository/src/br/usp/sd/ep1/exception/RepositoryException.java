package br.usp.sd.ep1.exception;

//exception que sera lancada pela service e capturada/tratada pela aplicacao cliente
public class RepositoryException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public RepositoryException(Exception ex) {
        super(ex);
    }

    public RepositoryException(String message) {
        super(message);
    }
}