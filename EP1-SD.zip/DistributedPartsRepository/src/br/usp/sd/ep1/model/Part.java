package br.usp.sd.ep1.model;

import java.util.List;

//interface que define os métodos de uma peca
public interface Part {

    Integer getCodigo();

    String getNomePeca();

    String getNomeRepo();

    String getDescricao();

    List<SubPart> getSubPecas();

    boolean ehPrimitiva();

    String toString2();
}