package br.usp.sd.ep1.model;

//interface que define os métodos específicos de uma subpeca (que também é um Part)
public interface SubPart extends Part {
 
    Part getPart();

    int getQuantidade();
}