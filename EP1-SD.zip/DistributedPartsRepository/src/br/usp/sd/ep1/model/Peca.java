package br.usp.sd.ep1.model;

import java.util.List;
import java.io.Serializable;

//classe que implementa a interface Part
public class Peca implements Part, Serializable {
	private static final long serialVersionUID = 1L;
	
	//atributos de uma peca
    private Integer codigo;
    private String nomePeca; 
    private String nomeRepo; 
    private String descricao;
    private List<SubPart> subPecas;

    //construtor que cria peca (primitiva ou agregada)
    public Peca(Integer codigo, String nomePeca, String nomeRepo, String descricao, List<SubPart> subPecas) {
        this.codigo = codigo;
        this.nomePeca = nomePeca;
        this.nomeRepo = nomeRepo;
        this.descricao = descricao;
        this.subPecas = subPecas;
    }
    
    //getters
    @Override
    public Integer getCodigo() {
        return this.codigo;
    }

    @Override
    public String getNomePeca() {
        return this.nomePeca;
    }

    @Override
    public String getNomeRepo() {
        return this.nomeRepo;
    }

    @Override
    public String getDescricao() {
        return this.descricao;
    }

    @Override
    public List<SubPart> getSubPecas() {
        return this.subPecas;
    }

    @Override
    public boolean ehPrimitiva() {
        return this.subPecas == null;
    }

    @Override
    public String toString() { //utilizado para exibir informacoes de uma peca (exibe as subpecas)
        return "\n[Peca: codigo= " + this.codigo
                + " nome da peca= " + this.nomePeca
                + " nome do repo= " + this.nomeRepo
                + " descricao= " + this.descricao + "]\n"
                + "----------------------------------------------------------------------------------------------------------------------------------------\n"
                + this.toStringSubparts();
    }

    @Override
    public String toString2() { //utilizado para exibir informacoes de todas as pecas do repo(nao exibe subpecas)
        String str = "[Peca: codigo= " + this.codigo
                + " nome da peca= " + this.nomePeca
                + " nome do repo= " + this.nomeRepo
                + " descricao= " + this.descricao;

        if (this.subPecas == null) {
            str += " peca primitiva (nao ha subpecas)]\n";
        } else {
            str += " peca agregada (" + this.subPecas.size() + " subpecas)]\n";
        }

        return str;
    }

    private String toStringSubparts() {
        StringBuilder strSubparts = new StringBuilder();
        
        if (!(this.subPecas == null)) {
            for (SubPart subpeca: this.subPecas) {
                strSubparts.append("[SUBPECA-> ");
                strSubparts.append(subpeca.getPart().toString());
                strSubparts.append(" quantidade= ");
                strSubparts.append(subpeca.getQuantidade());
                strSubparts.append("]\n");
                strSubparts.append("--------------------------------------------------------------------------------------------------------------------------\n");
            }
        } 

        return  strSubparts.toString();
    }
}
