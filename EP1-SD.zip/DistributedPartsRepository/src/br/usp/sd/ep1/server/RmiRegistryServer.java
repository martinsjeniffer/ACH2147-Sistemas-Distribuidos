package br.usp.sd.ep1.server;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;
import java.util.List;

import br.usp.sd.ep1.model.Part;
import br.usp.sd.ep1.model.SubPart;
import br.usp.sd.ep1.model.SubPeca;
import br.usp.sd.ep1.repository.PartRepository;
import br.usp.sd.ep1.repository.Server;

//aplicacao servidor, que registra os objetos no RMI Registry e disponibiliza para a aplicacao cliente
public class RmiRegistryServer {

    public static void main(String[] args) {

        PartRepository server;

        try {
            //criando o objeto que representa o RMI Registry Server (porta padrao é 1099)
            Registry registry = LocateRegistry.createRegistry(1099);

            List<SubPart> subpecas = new ArrayList<>();
            SubPart subpeca = null;

            //criando 10 objetos remotos, todos na mesma máquina (localhost)
            for (int i=1; i <= 10; i++) {

                //criando nosso objeto remoto e populando repository
                server = new Server("rmi://localhost/sd.ep1.DistributedPartsRepository" + i);

                /*para cada objeto remoto, sao criados 10 pecas, sendo os 5 primeiros objetos compostos 
                apenas de pecas primitivas e os 5 ultimos apenas de pecas agregadas*/
                
                //5 repositorios com apenas pecas primitivas
                if (i <= 5) {
                    for (int j=0; j < 10; j++) {
                        
                        Part peca = server.addPartRepo("part" + j, "peca " + j + " remote obj n=" + i, null);
                        subpeca = new SubPeca(peca, j + 3);
                        subpecas.add(subpeca);
                    }
                } 
                
                //5 repositorios com apenas pecas agregadas
                else {
                    for (int j=0; j < 10; j++) {
                        server.addPartRepo("part" + j, "peca " + j + " remote obj n=" + i, subpecas);
                    }
                }

                //registrando nosso objeto remoto no server
                registry.rebind(server.getNameRepo(), server);
            }

            System.out.println("Server on");

        } catch (RemoteException ex) {
            System.out.println("Server out");
            ex.printStackTrace();
        }
    }
}