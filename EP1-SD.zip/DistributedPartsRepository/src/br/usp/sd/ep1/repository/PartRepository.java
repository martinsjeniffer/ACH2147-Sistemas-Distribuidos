package br.usp.sd.ep1.repository;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

import br.usp.sd.ep1.model.Part;
import br.usp.sd.ep1.model.SubPart;

//interface principal, que define os métodos que podem ser acessados remotamente
public interface PartRepository extends Remote {

    String getNameRepo() throws RemoteException; //retorna o nome do repositorio

    Integer getQtdPartsRepo() throws RemoteException; //retorna a quantidade de pecas do repositorio

    Part getPartRepo(Integer codigo) throws RemoteException; //retorna determinada peca do repositorio

    List<Part> getRepo() throws RemoteException; //retorna todas as pecas do repositorio

    String listPartsRepo() throws RemoteException; //exibe todas as pecas do repositorio

    Part addPartRepo(String nome, String descricao, List<SubPart> subparts) throws RemoteException; //adiciona uma peca no repositorio 

    void addSubPartRepo(List<SubPart> subparts, Part part, int quantidade) throws RemoteException; //adiciona uma subpeca na lista de subpecas

    void removePartRepo(Part part) throws RemoteException; //remove uma peca do repositorio

    void alterPartRepo(Part part, String nome, String descricao) throws RemoteException; //altera uma peca do repositorio
}