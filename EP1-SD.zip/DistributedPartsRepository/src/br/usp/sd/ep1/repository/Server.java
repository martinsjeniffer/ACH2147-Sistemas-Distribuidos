package br.usp.sd.ep1.repository;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;

import br.usp.sd.ep1.model.Part;
import br.usp.sd.ep1.model.Peca;
import br.usp.sd.ep1.model.SubPart;
import br.usp.sd.ep1.model.SubPeca;

//classe que implementa o servidor de repositorio, com a implementacao dos metodos remotos
public class Server extends UnicastRemoteObject implements PartRepository {
	private static final long serialVersionUID = 1L;
	
	//atributos de um servidor: nome e lista de pecas
	private String name;
    private List<Part> repository;

    //construtor
    public Server(String name) throws RemoteException {
        this.name = name;
        this.repository = new ArrayList<>();
    }

    /*implementacao dos metodos remotos de PartRepository*/
    
    //retorna o nome do repositorio
    @Override
    public String getNameRepo() throws RemoteException {
        return this.name;
    }

    //retorna a quantidade de pecas do repositorio
    @Override
    public Integer getQtdPartsRepo() throws RemoteException {
        return this.repository.size();
    }

    //retorna determinada peca do repositorio (busca pelo codigo)
    @Override
    public Part getPartRepo(Integer codigo) throws RemoteException {
        return this.repository.stream()
                .filter(p -> p.getCodigo().equals(codigo))
                .findAny()
                .orElse(null);
    }

  //retorna todas as pecas do repositorio
    @Override
    public List<Part> getRepo() throws RemoteException {
        return this.repository;
    }

    //exibe todas as pecas do repositorio
    @Override
    public String listPartsRepo() throws RemoteException {
        StringBuilder str = new StringBuilder();

        this.repository.forEach(part -> {
            str.append(part.toString2());
        });

        return str.toString();
    }

    //adiciona uma peca no repositorio
    @Override
    public Part addPartRepo(String nome, String descricao, List<SubPart> subparts) throws RemoteException {
        int codigo = this.repository.size();
        Part part = new Peca(codigo, nome, this.name, descricao, subparts); 
        this.repository.add(part);
        return part;
    }

  //adiciona uma subpeca na lista de subpecas
    @Override
    public void addSubPartRepo(List<SubPart> subparts, Part part, int quantidade) throws RemoteException {
        SubPart subpart = new SubPeca(part, quantidade);
        subparts.add(subpart);
    }

    //remove uma peca do repositorio
    @Override
    public void removePartRepo(Part part) throws RemoteException {
        for (int i=0; i < this.repository.size(); i++) {
            Part pecaAtual = this.repository.get(i);
            if (pecaAtual.getCodigo().equals(part.getCodigo())) {
                this.repository.remove(i);
                break;
            }
        }
    }

    //altera uma peca do repositorio
    @Override
    public void alterPartRepo(Part part, String nome, String descricao) throws RemoteException {
        for (int i=0; i < this.repository.size(); i++) {
            Part pecaAtual = this.repository.get(i);

            if (pecaAtual.getCodigo().equals(part.getCodigo())) {
                Part novaPeca = new Peca(pecaAtual.getCodigo(), nome, this.name, descricao, pecaAtual.getSubPecas());
                this.repository.remove(i);
                this.repository.add(i, novaPeca);
                break;
            }
        }
    }
}